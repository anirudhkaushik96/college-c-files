#include <stdio.h>  
#include <stdlib.h>  
//queue functions
struct node   
{  
    int data;   
    struct node *next;  
}*front,*rear,*ptr;  

void enqueue()  
{    
    int item;
    ptr = (struct node *) malloc (sizeof(struct node));  
    if(ptr == NULL)  
    {  
        printf("\nOVERFLOW\n");   
    }  
    else  
    {   
    
        printf("Enter value?\n");  
        scanf("%d",&item);  
        ptr -> data = item;  
        if(front == NULL)  
        {  
            front = ptr;  
            rear = ptr;   
            front -> next = NULL;  
            rear -> next = NULL;  
        }  
        else   
        {  
            rear -> next = ptr;  
            rear = ptr;  
            rear->next = NULL;  
        }  
    }  
}     
void dequeue ()  
{   
    if(front == NULL)  
    {  
        printf("UNDERFLOW\n"); 
    }  
    else   
    {  
        ptr = front;  
        front = front -> next;
        printf("Deleted item is %d\n",ptr->data);
    }  
}  
void display()  
{    
    ptr = front;      
    if(front == NULL)  
    {  
        printf("Empty queue\n");  
    }  
    else  
    {   printf("Values in Queue:\n");  
        while(ptr != NULL)   
        {  
            printf("%d\t",ptr -> data);  
            ptr = ptr -> next;  
        } 
		printf("\n"); 
    }  
}

//stack functions
struct node1{  
	int val1;  
	struct node *next1;  
}*head1,*ptr1;  
void push ()  
{  
    int val1;  
    ptr1= (struct node*)malloc(sizeof(struct node1*));   
    if(ptr1 == NULL)  
    {  
        printf("Not able to push the element\n");   
    }  
    else   
    {  
        printf("Enter the value\n");  
        scanf("%d",&val1);  
        if(head1==NULL)  
        {         
            ptr1->val1 = val1;  
            ptr1-> next1 = NULL;  
            head1=ptr1;  
        }   
        else   
        {  
            ptr1->val1 = val1;  
            ptr1->next1 = head1;  
            head1=ptr1;        
        }  
        printf("Item pushed\n");     
    }  
}  
  
void pop()  
{  
    int item;    
    if (head1 == NULL)  
    {  
        printf("Underflow");  
    }  
    else  
    {  
        item = head1->val1;  
        ptr1 = head1;  
        head1 = head1->next1;   
        printf("Item popped %d",item);     
    }  
}  
void displaystack()  
{  
    int i;   
    ptr1=head1;  
    if(ptr1 == NULL)  
    {  
        printf("Stack is empty\n");  
    }  
    else  
    {  
        printf("Printing Stack elements \n");  
        while(ptr1!=NULL)  
        {  
            printf("%d\n",ptr1->val1);  
            ptr1 = ptr1->next1;  
        }  
    }  
}

