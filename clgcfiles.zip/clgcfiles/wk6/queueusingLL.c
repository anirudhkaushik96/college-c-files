#include <stdio.h>
#include "mainfunctionsLL.c"

int main ()  
{  
    int choice;
	printf("Main Menu\n");  
    printf("1.Insert\n2.Delete an element\n3.Display the queue\n4.Exit\n");   
    while(choice != 4)   
    {     
        printf("Enter your choice\n");  
        scanf("%d",& choice);  
        switch(choice)  
        {  
            case 1:  
            enqueue();  
            break;  
            case 2:  
            dequeue();  
            break;  
            case 3:  
            display();  
            break;  
            case 4:  
            exit(0);  
            default:   
            printf("Enter valid choice\n");  
        }  
    }  
    return 0;
}  