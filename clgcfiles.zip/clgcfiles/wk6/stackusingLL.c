#include <stdio.h>
#include "mainfunctionsLL.c"
int main ()  
{  
    int choice;
	printf("Main Menu\n");  
    printf("1.Insert\n2.Delete \n3.Display \n4.Exit\n");   
    while(choice != 4)   
    {     
        printf("Enter your choice\n");  
        scanf("%d",& choice);  
        switch(choice)  
        {  
            case 1:  
            push();  
            break;  
            case 2:  
            pop();  
            break;  
            case 3:  
            displaystack();  
            break;  
            case 4:  
            exit(0);   
            default:   
            printf("Enter valid choice\n");  
        }  
    }  
    return 0;
}  