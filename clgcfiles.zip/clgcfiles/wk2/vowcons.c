#include <stdio.h>
//vowel or consonant
int main(){
	char ch;
	printf("Enter an alphabet:\n");
	scanf("%c",&ch);
	switch (ch){
		case 'a':
		case 'e':
		case 'i':		
		case 'o':
		case 'u':
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U':
			printf("Vowel");
			break;
		default:
			printf("Consonant");
	}
	return 0;
}
