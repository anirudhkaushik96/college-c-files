#include <stdio.h>
//multiplication table
int main(){
	int n,i=1;
	printf("Enter number for multiplication table: ");
	scanf("%d",&n);
	do{
		printf("%d*%d= %d\n", n,i,n*i);
		i++;
	}while(i<11);
	return 0;
}
