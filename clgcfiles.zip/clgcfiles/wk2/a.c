#include <stdio.h>
#include <math.h>
//armstrong number
int main(){
	int n,na;
	int i,r,count=0,sum=0,l;
	printf("Enter number: ");
	scanf("%d",&n);
	na=n;
	while (n>0){
		r=n%10;
		count=count+1;
		n=n/10;
	}
	n=na;
	while (na>0){
		r=na%10;
		int l=pow(r,count);
		sum=sum+l;
		na=na/10;
	}

	if (sum==n){
		printf("Armstrong number\n");
	}
	else{
		printf("Not an armstrong number\n");
	}
	return 0;
}
//gcc a.c -o a -lm

