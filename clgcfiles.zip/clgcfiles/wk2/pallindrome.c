#include <stdio.h>
//pallindrome
int main(){
	int r,ps=0,num1;
	printf("Enter number: ");
	scanf("%d",&num1);
    int n=num1;
	while (n>0){
		r=n%10;
		ps=ps*10+r;
		n=n/10;
	}
    if (ps==num1){
        printf("pallindrome\n");
    }
    else{
        printf("not a pallindrome\n");
    }
}