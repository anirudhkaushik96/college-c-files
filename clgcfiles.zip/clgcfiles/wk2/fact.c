#include <stdio.h>
//factorial of a number
int main(){
    long double n,nf=1;
    int i=1;
    printf("Enter number to find factorial\n");
    scanf("%Lf", &n);
    for (i=1;i<=n;i++){
        nf=nf*i;
    }
    printf("%.2Lf",nf);
}