#include <stdio.h>
//even and odd numbers 
int main(){
    int n,no=1,ne=2;
    printf("Enter the number upto which even and odd numbers are printed: ");
    scanf("%d",&n);
    printf("Even numbers: \n");
    while(ne<=n&&ne%2==0){
        printf("%d ",ne);
        ne=ne+2;
    }
    printf("\nOdd numbers: \n");
    while(no<=n&&no%2!=0){
        printf("%d ",no);
        no=no+2;
    }
    return 0;
}