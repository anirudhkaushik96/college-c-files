#include <stdio.h>
//grading and percentage
int main(){
	int a,b,c,d,e,f,total=0;
	float perc;
	printf("Enter marks in 6 subjects(each subject out of 100):");
	scanf("%d %d %d %d %d %d",&a,&b,&c,&d,&e,&f);
	total=a+b+c+d+e+f;
	printf("Total marks obtained: %d\n", total);
	perc=(float)(total*100)/600;
	printf("Percentage obtained: %.2f\n", perc);
	printf("Total grade: ");
	if (perc>91&&perc<=100){
		printf("S");
	}
	else if (perc>91&&perc<=100){
		printf("A");
	}
	else if (perc>81&&perc<=90){
		printf("B");
	}
	else if (perc>71&&perc<=80){
		printf("C");
	}
	else if (perc>61&&perc<=70){
		printf("D");
	}
	else{
		printf("Enter valid marks");
	}
	return 0;
}
