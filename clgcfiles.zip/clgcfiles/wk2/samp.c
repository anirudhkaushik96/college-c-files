#include <stdio.h>
#include <math.h>

int main(){
    double p=pow(2,3);
    printf("%f",p);
}