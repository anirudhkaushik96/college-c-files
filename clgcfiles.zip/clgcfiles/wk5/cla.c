
#include <stdio.h>
// command line arguments
int main(int argc, char* argv[])
{
    printf("Program name is: %s\n", argv[0]);
    if (argc == 1)
    printf("Program name passed: %s\n",argv[0]);
    if (argc >= 2) {
        printf("No. args: %d\n", argc);
        printf("Command Line Arguments Passed:\n");
        for (int i = 0; i < argc; i++)
        printf("argv[%d]: %s\n", i, argv[i]);
    }
    return 0;
}
