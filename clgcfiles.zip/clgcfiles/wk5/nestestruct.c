#include <stdio.h>
//nested structure
int main(){
    struct student{
        int roll;
        char name[10];
        struct dob{
            int dd;
            int mm;
            int yyyy;
        }dob1;
    };
    struct student s1={56,"student1",{22,03,2004}};
    printf("Name: %s\n",s1.name);
    printf("Roll number: %d\n",s1.roll);
    printf("Date of birth: %d/%d/%d",s1.dob1.dd,s1.dob1.mm,s1.dob1.yyyy);
}