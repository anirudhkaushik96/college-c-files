#include <stdio.h>
//unions
int main(){
    union student{
        int roll;
        char name[10];
    };
    union student u1={234,"name1"};
    //sizeof union
    printf("%d\n",sizeof(u1));
    //accessing union elements
    printf("roll number: %d\n",u1.roll);
    printf("name: %s",u1.name);
}