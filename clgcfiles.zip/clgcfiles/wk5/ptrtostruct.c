#include <stdio.h>
//pointer to structure
int main(){
    struct student{
        int roll;
        char name[10];
        float perc;
        struct dob{
            int dd;
            int mm;
            int yyyy;
        }dob1;
    };
    struct student s1;
    struct student *p;
    p=&s1;
    printf("Enter details:\n");
    scanf("%d",&p->roll);
    scanf("%s",p->name);
    scanf("%f",&p->perc);
    scanf("%d",&p->dob1.dd);
    scanf("%d",&p->dob1.mm);
    scanf("%d",&p->dob1.yyyy);
    printf("Roll number: %d\n",p->roll);
    printf("Name: %s\n",p->name);
    printf("Percentage: %.4f\n",p->perc);
}