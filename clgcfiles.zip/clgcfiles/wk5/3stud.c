
//rollno, name, marks of three subjects and average using structure concept.
#include <stdio.h>
struct studt3 {
    int rollno;
    char name[20];
    int marks[3];
    float ave;

};
int main() {
    struct studt3 stud;
    struct studt3 *p1;
    p1=&stud;
    int i, j;
    for (i = 0; i < 2; i++) {
        printf("Enter roll no. %d:\n", i + 1);
        scanf("%d", &p1->rollno);
        printf("Name %d:\n", i + 1);
        scanf("%s", p1->name);
        int t=0;
        for (j = 0; j < 3; j++) {
            printf("Marks %d: ", j + 1);
            scanf("%d", &p1->marks[j]);
            t += p1->marks[j];
        }
        p1->ave= t / 3.0;
        printf("Average: %.2f\n", p1->ave);
    }
    return 0;
}
/*Enter roll number of student 1:
 36
Enter name of student 1: 
io
Enter marks for subject 1: 89
Enter marks for subject 2: 78
Enter marks for subject 3: 45
Average: 70.67
Enter roll number of student 2:
 69
Enter name of student 2: 
oi
Enter marks for subject 1: 12
Enter marks for subject 2: 32
Enter marks for subject 3: 54
Average: 32.67*/