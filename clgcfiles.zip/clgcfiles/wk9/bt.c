
#include <stdio.h>
#include <stdlib.h>
#include "mainfunctree.c"

int main(){
	struct node *root=newNode(20);
	root->left=newNode(30);
	root->right=newNode(40);
	root->left->left=newNode(50);
	root->left->right=newNode(60);
    printf("Preorder: ");
	preorder(root);
	printf("\n");
    printf("Inorder: ");
	inorder(root);
	printf("\n");
    printf("Postorder: ");
	postorder(root);
	return 0;
	
}
