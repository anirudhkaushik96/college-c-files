#include <stdio.h>
#include <stdlib.h>
#include "mainfunctree.c"


int main() {
  int i,data;
  create();
  struct node *root = NULL;
  temp=head;
  while(temp!=NULL){
  	root=insert(root, temp->val);
  	temp=temp->next;
  }
  
  printf("\npreorder:");
  preorder(root);printf("inorder:");
  inorder(root);
  printf("\npostorder:");
  postorder(root);
  printf("\n");
  printf("Min value in given bst:\n");
  display(minvalue(root));
  printf("Max value in given bst:\n");
  display(maxvalue(root));
  printf("Delete element:\n");
  scanf("%d",&data);
  delete(root,data);
  printf("\nPreorder after deletion:");
  preorder(root);
  printf("\nInorder after deletion:");
  inorder(root);
  printf("\nPostorder after deletion:");
  postorder(root);
}
