#include <stdio.h>
#include <stdlib.h>
struct node{
	int data;
	struct node *left;
	struct node *right;
};

struct node *newNode(int data){
	struct node *node=(struct node *)malloc(sizeof(struct node));
	node->data=data;
	
	node->left=NULL;
	node->right=NULL;
	return (node);
}

struct node1{
	int val;
	struct node *next;
}*head,*new,*tail,*temp;
void create(){
	int data,c=1;
	while(c)
	{
		new=(struct node1*)malloc(sizeof(struct node1));
		printf("Enter value\n");
		scanf("%d",&data);
		new->val=data;
		new->next=NULL;
		if(head==NULL){
			head=new;
			tail=new;
		}
		else{
			tail->next=new;
			tail=new;
		}
		printf("Press 1 to continue\n");
		scanf("%d",&c); 
	}
}

struct node *insert(struct node *node, int data) {
  if (node == NULL)
   return newNode(data);
  if (data < node->data)
    node->left = insert(node->left, data);
  else
    node->right = insert(node->right, data);
  return node;
}
struct node *minvalue(struct node *node) {
  struct node *current = node;
  while (current && current->left != NULL)
    current = current->left;

  return current;
}
struct node *maxvalue(struct node *node) {
  struct node *current = node;
  while (current && current->right != NULL)
    current = current->right;
  return current;
}
struct node *delete(struct node *root, int data) {

  if (root == NULL)
   return root;
  if (data < root->data)
    root->left = delete(root->left, data);
  else if (data > root->data)
    root->right = delete(root->right, data);
  else {
    if (root->left == NULL) {
      struct node *temp = root->right;
      free(root);
      return temp;
    } else if (root->right == NULL) {
      struct node *temp = root->left;
      free(root);
      return temp;
    }
    struct node *temp = minvalue(root->right);
    root->data = temp->data;
    root->right = delete(root->right, temp->data);
    return root;
  }
}

void display(struct node *root){
	printf("the required is element is: %d\n",root->data);
}

void preorder(struct node *root){
  
	if (root!=NULL){
        
		printf("%d\t",root->data);
		preorder(root->left);
		preorder(root->right);
	}
}

void inorder(struct node *root){
    
	if (root!=NULL){
       
		inorder(root->left);
		printf("%d\t",root->data);
		inorder(root->right);
	}
}

void postorder(struct node *root){
	if (root!=NULL){
		postorder(root->left);
		postorder(root->right);
		printf("%d\t",root->data);
	}
}