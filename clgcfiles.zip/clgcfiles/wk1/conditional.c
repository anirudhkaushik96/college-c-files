//conditional statement
#include <stdio.h> 

int main(){ 
	int a,b;
	printf("Input 2 numbers:");
	scanf("%d %d",&a,&b);
    printf("a=%d\nb=%d\n",a,b);
	(a>b)?printf("a>b\n"):printf("b<a\n"); 
	return 0; 
}
