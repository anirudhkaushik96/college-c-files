//Input a number, a character and a float point number
#include <stdio.h>

int main(){
	int n;
	char c;
	float p;
	printf("Input a number, a character and a float point number\n");
	scanf("%d\n",&n);
	scanf("%c\n",&c);
	scanf("%f",&p);	
	printf("\nNumber given-%d, character-%c, percentage-%.3f% \n",n,c,p);
	return 0;
}
