//performing arithmetic operations for 2 numbers
#include <stdio.h>

int main(){
	int n1,n2;
	printf("Input 2 numbers:");
	scanf("%d %d",&n1,&n2);
	printf("Sum of numbers: %d\n", n1+n2);
	printf("Difference of numbers: %d\n", n1-n2);
	printf("Product of numbers: %d\n", n1*n2);
	printf("Division of numbers: %.2f\n", (float)n1/n2);
	printf("Modulo Division of numbers: %d\n", n1%n2);
	return 0;
}
