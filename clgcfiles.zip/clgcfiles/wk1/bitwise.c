//bitwise operators

#include <stdio.h>

int main(){
	int a,b;
	printf("Input 2 numbers\n");
	scanf("%d %d", &a,&b);
	printf("a=%d\nb=%d\n",a,b);
	printf("%d bitwise and a&b\n", a&b);
	printf("%d bitwise or a|b\n", a|b);
	printf("%d bitwise xor a^b\n", a^b);
	printf("%d bitwise not ~a\n", ~a);
	printf("%d bitwise shift right a>>3\n", a>>3);
	printf("%d bitwise shift left a<<3\n", a<<3);
	return 0;
}
