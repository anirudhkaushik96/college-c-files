//to demonstrate logical operators
#include <stdio.h>

int main(){
	int a,b,c;
	printf("Enter 3 numbers:\n");
	scanf("%d %d %d",&a,&b,&c);
	printf("a=%d\nb=%d\nc=%d\n",a,b,c);
	printf("1 refers to true and 0 to false\n");
	printf("%d a<b logical AND c>b \n",a<b&&c>b);
	printf("%d b<=a logical OR b>=c\n",b<=a||b>=c);
	printf("%d logical NOT !(a>b)\n", !(a>b));	
	return 0;
}
