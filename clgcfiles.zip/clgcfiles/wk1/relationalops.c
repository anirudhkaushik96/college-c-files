//to demonstrate relational operators
#include <stdio.h>

int main(){
	int a,b,c;
	printf("Enter 3 numbers:\n");
	scanf("%d %d %d",&a,&b,&c);
	printf("a=%d\nb=%d\nc=%d\n",a,b,c);
	printf("1 refers to true and 0 to false\n");
	printf("%d a<b relational <\n%d c>b relational >\n",a<b,c>b);
	printf("%d b<=a relational <=\n%d b>=c relational >=\n",b<=a,b>=c);
	printf("%d relational equal to a==9\n",a==9);
	return 0;
}
