//sizeofdatatype
#include <stdio.h>

int main(){
	printf("Size of void %ld bytes\n", sizeof(void));
	printf("Size of integer %ld bytes\n", sizeof(int));
	printf("Size of character %ld bytes\n", sizeof(char));
	printf("Size of short %ld bytes\n", sizeof(short));
	printf("Size of float %ld bytes\n", sizeof(float));
	printf("Size of long %ld bytes\n", sizeof(long));
	printf("Size of double %ld bytes\n", sizeof(double));
	printf("Size of long double %ld bytes\n", sizeof(long double));
	return 0;	
}
