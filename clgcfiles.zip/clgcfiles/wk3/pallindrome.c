#include <stdio.h>
//pallindrome number
int pal(int x){
	int num1=x,r,ps=0;
	while (x>0){
		r=x%10;
		ps=ps*10+r;
		x=x/10;
	}
	if (ps==num1){
		printf("Pallindrome number\n");
	}
	else{
		printf("Not a pallindrome number\n");
	}
}

int main(){
	int n;
	printf("Enter number to check if pallindrome or not:\n");
	scanf("%d",&n);
	pal(n);
	return 0;
}
