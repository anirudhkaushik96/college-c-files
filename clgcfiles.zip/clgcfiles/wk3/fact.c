#include <stdio.h>
//factorial of number
void fact(int x){
	int nf=1;
	int i=1;
	for (i=1;i<=x;i++){
		nf=nf*i;
	}
	printf("\nFactorial is: %d\n",nf);
}

int main(){
	int n;
	printf("Enter number to find factorial for: \n");
	scanf("%d",&n);
	fact(n);
	return 0;
}
