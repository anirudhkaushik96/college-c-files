#include <stdio.h>
//prime or not
int primon(int x){
	int i,m=0;
	
	for (i=2;i<=x-1;i++){
		if (x%i==0){
			m=1;
			break;
		}
}
	if (m==0){
		printf("Prime number");
	}
	else{
		printf("Not a prime number");
	}
}

int main(){
	int n;
	printf("Enter number to check whether prime or not: ");
	scanf("%d",&n);
	primon(n);
	return 0;
}
