#include <stdio.h>
//prg to print fibonacci series
int fibo(int x){
	int f=0,s=1,i;
	printf("Series is: %d %d ",f,s);
	for (i==0;i<x-2;i++){
		int t=f+s;
		printf("%d ",t);
		f=s;
		s=t;
	}
}

int main(){
	int n,i;
	printf("Enter number to print fibonacci: \n");
	scanf("%d",&n);
	fibo(n);
	return 0;
}

