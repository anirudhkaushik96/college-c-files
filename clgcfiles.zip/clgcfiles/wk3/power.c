#include <stdio.h>
//power of a number
int power(int a,int b){
	if (b==0){
		return 1;
	}
	else if (b==1){
		return a;
	}
	else{
		return a*power(a,b-1);
	}
}

int main(){
	int x,y;
	printf("Enter base and exponent to find the power of a number: \n");
	scanf("%d %d",&x,&y);
	printf("%d",power(x,y));
	return 0;
}
