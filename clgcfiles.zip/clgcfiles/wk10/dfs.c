#include<stdio.h>
int top=-1,a[20][20],v[10],stack[10],n;

int pop();
void dfs(int s,int n);
int main(){
	int i,s,j;
	printf("Vertices: ");
	scanf("%d",&n);
	printf("Enter adjacency matrix:\n");
	for(i=1;i<=n;i++){
	for(j=1;j<=n;j++)
	scanf("%d",&a[i][j]);
	}
	for(i=1;i<=n;i++)
		v[i]=0;
	printf("\n1.Depth First Search\n");
	printf("Enter source vertex:");
	scanf("%d",&s);
	dfs(s,n);
    printf("\n");
	return 0;
}

int pop(){
    	int k;
	if(top==-1)
		return(0);
	else{
		k=stack[top--];
		return(k);
	}
}

void dfs(int s, int n){
    	int i,k;
	stack[++top]=s;
	v[s]=1;
    k=pop();
	if(k!=0)
		printf(" %d ",k);
	while(k!=0&&top<10){
		for(i=1;i<=n;i++){
			if((a[k][i]!=0)&&(v[i]==0)){
				stack[++top]=i;
				v[i]=1;
			}
		}
		k=pop();
		if(k!=0)
			printf(" %d ",k);
	}
	for(i=1;i<=n;i++)
		if(v[i]==0)
			dfs(i,n);
}