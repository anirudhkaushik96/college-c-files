#include<stdio.h>
int q[10],front=-1,rear=-1,a[20][20],v[10],n;

int dequeue();
void bfs(int s, int n);

int main(){
	int i,s,j;
	printf("Enter the number of vertices:");
	scanf("%d",&n);
	printf("Enter adjacency matrix:\n");
	for(i=1;i<=n;i++){
	for(j=1;j<=n;j++)
	scanf("%d",&a[i][j]);
	}
	for(i=1;i<=n;i++)
		v[i]=0;
	printf("\nBreadth First Search\n");
	printf("Enter source vertex:");
	scanf("%d",&s);
	bfs(s,n);
    printf("\n");
	return 0;
}

int dequeue(){
	int k;
	if((front>rear)||(front==-1))
		return(0);
	else{
		k=q[front++];
		return(k);
	}
}
void bfs(int s,int n){
	int p,i;
	if (rear<10){
        if(rear==-1){
	      	q[++rear]=s;
			front++;
		}
	    else
		q[++rear]=s;
    }
	p=dequeue();
	if(p!=0)
	printf("%d",p);
	while(p!=0&&rear<10){
		for(i=1;i<=n;i++){
			if((a[p][i]!=0)&&(v[i]==0)){
				q[++rear]=i;
				v[i]=1;
			}
		}
		p=dequeue();
	    if(p!=0)
		    printf(" %d ",p);
	}
	for(i=1;i<=n;i++)
		if(v[i]==0)
			bfs(i,n);
}
