#include <stdio.h>
//swap integers
void swap (int *x,int *y){
    int m=*x;
    *x=*y;
    *y=m;
}

int main(){
    int a,b;
    scanf("%d %d",&a,&b);
    swap(&a,&b);
    printf("a=%d,b=%d\n",a,b);
}