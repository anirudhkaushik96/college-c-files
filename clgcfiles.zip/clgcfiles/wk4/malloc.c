#include <stdio.h>
#include <stdlib.h>
//malloc() function
int main(){
    int *p;
    int n,i;
    printf("Enter number of elements: ");
    scanf("%d",&n);
    p=(int*)malloc(n*sizeof(int));
    if (p==NULL){
        printf("No memory allocated\n");
        exit(0);
    }
    else{
        printf("Memory allocated\nEnter values into an array:\n");
        for (i=0;i<n;i++)
        scanf("%d",&p[i]);
        printf("Address of elements:\n");
        for (i=0;i<n;i++)
        printf("%d\t%p\t\n",p[i],p+i);
    }
}