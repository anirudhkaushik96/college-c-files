#include <stdio.h>
//sum,max,min,elements of array
int main(){
	int size,a[10],i,j,sum=0;
	printf("Enter size of array (max 10): ");
	scanf("%d",&size);
	printf("Enter elements in array:\n");
	for (i=0;i<size;i++){
		scanf("%d",&a[i]);
	}
	for(j=0;j<size;j++){
		sum=sum+a[j];
	}
	printf("Sum of elements: %d ",sum);
	int min=a[0];
	int max=a[0];
	for (i=0;i<size;i++){
		if (a[i]<min){
			min=a[i];
		}
		else {
			if (a[i]>max){
				max=a[i];
			}
		}
	}
	printf("\nMax: %d, min:%d",max,min);
	return 0;
}
