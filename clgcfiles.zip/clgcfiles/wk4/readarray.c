#include <stdio.h>
//read values into an array
int main(){
	int size,a[10],i;
	printf("Enter size of array (max 10): ");
	scanf("%d",&size);
	printf("Enter elements in array:");
	for (i=0;i<size;i++){
		scanf("%d",&a[i]);
	}
	for (i=0;i<size;i++)
	printf("%d ",a[i]);
	return 0;
}
