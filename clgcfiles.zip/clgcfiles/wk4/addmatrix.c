#include <stdio.h>
//add two matrices
int main(){
	int i,j,m,n,a[10][10],b[10][10],c[10][10];
	printf("number of rows and columns: ");
	scanf("%d%d",&m,&n);
	printf("Enter elements in matrices a:\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	printf("Elements in a:\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	printf("Enter elements in matrices b:\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			scanf("%d",&b[i][j]);
		}
	}
	printf("Elements in b:\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			printf("%d\t",b[i][j]);
		}
		printf("\n");
	}
	printf("Matrix c:\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			c[i][j]=a[i][j]+b[i][j];
		}
	}
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			printf("%d\t",c[i][j]);
		} 
	printf("\n");
}
	return 0;
}