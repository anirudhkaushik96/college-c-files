#include <stdio.h>
#include <stdlib.h>
//malloc() function
int main(){
    int *p;
    int n1,n2,i;
    printf("Enter number of elements: ");
    scanf("%d",&n1);
    p=(int*)calloc(n1,sizeof(int));
    if (p==NULL){
        printf("No memory allocated\n");
        exit(0);
    }
    else{
        printf("Memory allocated\nEnter values into an array:\n");
        for (i=0;i<n1;i++){
            scanf("%d",p+i);
            printf("%p\n",p+i);
        }
        printf("New size: ");
        scanf("%d",&n2);
        p=realloc(p,n2*sizeof(int));
        printf("Address of newly allocated memory:\n");
        for (i=0;i<n1;i++){
            printf("%p\n",p+i);
        } 
        free(p);
        return 0;
    }
}