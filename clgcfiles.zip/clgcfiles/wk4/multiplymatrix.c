#include <stdio.h>
//add two matrices
int main(){
	int i,j,m1,n1,m2,n2,k,a[10][10],b[10][10],c[10][10];
	printf("number of rows and columns in matrix a: ");
	scanf("%d%d",&m1,&n1);
	printf("Enter elements in matrices a:\n");
	for (i=0;i<m1;i++){
		for (j=0;j<n1;j++){
			scanf("%d",&a[i][j]);
		}
	}
	printf("Elements in a:\n");
	for (i=0;i<m1;i++){
		for (j=0;j<n1;j++){
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	printf("number of rows and columns in matrix b: ");
	scanf("%d%d",&m2,&n2);
	printf("Enter elements in matrices b:\n");
	for (i=0;i<m2;i++){
		for (j=0;j<n2;j++){
			scanf("%d",&b[i][j]);
		}
	}
	printf("Elements in b:\n");
	for (i=0;i<m2;i++){
		for (j=0;j<n2;j++){
			printf("%d\t",b[i][j]);
		}
		printf("\n");
	}
	printf("Matrix c:\n");
	if (n1==m2){
	    for (i=0;i<m1;i++){
		    for (j=0;j<n2;j++){
		        c[i][j]=0;
			    for (k=0;k<m2;k++){
			        c[i][j]+=a[i][k]*b[k][j];
			    }
		} 
	    }
	    	
	}
	for (i=0;i<m1;i++){
		for (j=0;j<n2;j++){
			printf("%d\t",c[i][j]);
		}
		printf("\n");
	}

	return 0;
}