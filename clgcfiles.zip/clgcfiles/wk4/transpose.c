#include <stdio.h>
//transpose of a matrix
int main(){
	int i,j,m,n,a[20][20],c[20][20];
	printf("number of rows and columns: ");
	scanf("%d%d",&m,&n);
	printf("Enter elements in matrices a:\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			scanf("%d",&a[i][j]);
		}
	}
	printf("Elements in a:\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			printf("%d\t",a[i][j]);
		}
		printf("\n");
	}
	printf("Matrix c (transpose of a):\n");
	for (i=0;i<m;i++){
		for (j=0;j<n;j++){
			c[j][i]=a[i][j];
		}
	}
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			printf("%d\t",c[i][j]);
		} 
	printf("\n");
}
	return 0;
}