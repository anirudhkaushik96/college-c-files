#include<stdio.h>
#include<stdlib.h>

struct node{
	struct node *prev;
	int data;
	struct node *next;
}*head,*tail,*new,*temp;
struct node* head=NULL;

void del();
void insert();
void display();

int main(){
	struct node *new;
	int data,c=1;
	while(c){
		new=(struct node*)malloc(sizeof(struct node));
		printf("Enter value\n");
		scanf("%d",&data);
		new->data=data;
		new->next=NULL;
		if(head==NULL){
			head=new;
			tail=new;
		}
		else{
			tail->next=new;
			new->prev=tail;
			tail=new;
		}
		printf("Press 1 to create more nodes\n");
		scanf("%d",&c); 
	}
	int m=1,a;
	printf("MENU LIST\n1.Insert\n2.Delete\n3.Display\n4.Exit\n");
	while(m==1)
	{
		printf("Enter choice\n");
		scanf("%d",&a);
		switch(a){
			case 1:insert();
			break;
			case 2:del();
			break;
			case 3:display();
			break;
			case 4:exit(0);
			break;
		}
		printf("Press 1 to continue\n");
		scanf("%d",&m); 
	}
    return 0;
}

void del()
{
	struct node* temp;
	int x,pos,i;
	temp=head;
	if(head==NULL){
		printf("LL is empty\n");
		return;
	}
	printf("Delete element at\n1.Started\n2.End\n3.Random\n");
	scanf("%d",&x);
	if(x==1){
		head=head->next;
		head->prev=NULL;
		temp->next=NULL;
	}
	if(x==2){
		while(temp->next!=tail){
			temp=temp->next;
		}
		temp->next=NULL;
		tail->prev=NULL;
		tail=temp;
	}
	if(x==3){
		printf("Enter pos: \n");
		scanf("%d",&pos);
		for(i=0;i<pos-1;i++){
			temp=temp->next;
		}
		temp->next=temp->next->next;
		temp->next->prev=temp;
	}
}

void insert()
{
	struct node *new1,*temp;
	int value,choice,pos,i;
	new1=(struct node*)malloc(sizeof(struct node));
	printf("Insert element at\n1.Start\n2.Random\n3.End\n");
	scanf("%d",&choice);
	printf("Enter data\n");
	scanf("%d",&value);
	new1->data=value;
	if(choice==1){
	    new1->next=head;
	    new1->prev=NULL;
	    head->prev=new1;
	    head=new1;
	    return;
	}
	if(choice==2){
		printf("Enter pos:\n");
	    scanf("%d",&pos);
	    temp=head;
	    for(i=0;i<pos-1;i++)
	    {
		    temp=temp->next;
        }
         new1->next=temp->next;
         temp->next=new1;
         new1->prev=temp;
	    new1->next->prev=new1;
	    temp=new1;
	    return;
	}
	if(choice==3){
	    new1->next=NULL;
	    new1->prev=tail;
	    tail->next=new1;
	    tail=new1;
	}
}
void display()
{
	struct node *temp1;
	int count=0;
	temp1=head;
	if(head==NULL){
		printf("LL is empty\n");
	}
	else{
		while(temp1!=tail){
		printf("%d\n",temp1->data);
		temp1=temp1->next;
		count++;
	}
	printf("%d",temp1->data);
	count+=1;
	printf("No.of elements %d\n",count);
	}
		
}
