#include<stdio.h>
#include<stdlib.h>
//create display and insert elements in circular linked list
struct node{
		int data,c,count;
		struct node *next;
	}*head,*new1,*tail,*temp;
	void First();
	void End();
	void Random();
	int data;
	int main()
	{
		int i,data,c=1,count=0;
		head=NULL;
		
		while(c==1)
		{
			new1=(struct node*)malloc(sizeof(struct node*));
			printf("enter data");
			scanf("%d",&data);
			new1->data=data;
			new1->next=NULL;
			if(head==NULL)
			{
				head=new1;
				tail=new1;
			}
			else
			{
				tail->next=new1;
				tail=new1;
			}
			printf("to continue press 1 or press 0 to not");
			scanf("%d",&c);
		}
		temp=head;
		if(head==NULL)
		{
			printf("linked list is empty");
		}
		else{
			while(temp!=NULL)
			{
				printf("%d\t",temp->data);
				temp=temp->next;
				count++;
			}
			printf("\n");
			printf("the no.of nodes in linkedlist %d",count);
		}
		i=0;
		do{
			
			printf("Menu to insert\n1.At First\n2.At End\n3.At Random\n4.Stop insertion");
			printf("Enter the choice");
			scanf("%d",&i);
			
			if(i==1){
				
				First();
			}
			else if(i==2){
				End();
			}
			else if(i==3){
				Random();
			}
			else{
			printf("Insertion stopped");
			break;
		}
		printf("enter data");
		scanf("%d",&data);
		new1->data=data;	
		}while(i!=4);
		temp=head;
		if(head==NULL)
		{
			printf("linked list is empty");
		}
		else{
			int i=0;
			while(temp!=head||i==0)
			{
				printf("%d\t",temp->data);
				temp=temp->next;
				i++;
			}
			printf("\n");
		}
	return 0;
}
void First(){
	
	new1->next=head;
	tail->next=new1;
	head=new1;	
}
void End(){
	tail->next=new1;
	new1->next=head;
	tail=new1;	
}
void Random(){
	int j,pos;
	printf("Enter the position");
	scanf("%d",&pos);
	temp=head;
	for(j=0;j<pos-1;j++)
	{
		temp=temp->next;
	}
	new1->next=temp->next;
	temp->next=new1;
}

void iFirst(){
	temp=head;
	head=head->next;
	temp->next=NULL;	
}
void iEnd(){
	temp=head;
	while(temp!=NULL){
		temp->next;
	}	
	temp->next=NULL;
	tail=temp;
}
void iRandom(){
	int j,pos;
	printf("Enter the position");
	scanf("%d",&pos);
	temp=head;
	for(j=0;j<pos-1;j++)
	{
		temp=temp->next;
	}
	new1->next=temp->next;
	temp->next=new1;
}
